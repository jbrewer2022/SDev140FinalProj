import tkinter as tk
from tkinter import messagebox

# Function to validate the login credentials
def validate_login(username, password):
    # Implement your own validation logic here
    # For demonstration purposes, we are checking against the saved credentials
    return username == saved_username and password == saved_password

# Function to handle the login button click
def on_login():
    username = entry_username.get()
    password = entry_password.get()
    if not username or not password:
        messagebox.showerror("Error", "Please enter both username and password.")
        return

    if validate_login(username, password):
        login_window.withdraw()
        main_window.deiconify()
    else:
        messagebox.showerror("Error", "Invalid username or password.")

# Function to handle the exit button click
def on_exit():
    if messagebox.askyesno("Exit", "Are you sure you want to exit?"):
        login_window.destroy()

# Function to handle the back button click (go back to the login window)
def on_back():
    main_window.withdraw()
    login_window.deiconify()

# Function to update the login credentials in the main window
def update_credentials():
    global saved_username, saved_password
    new_username = entry_new_username.get()
    new_password = entry_new_password.get()
    if not new_username or not new_password:
        messagebox.showerror("Error", "Please enter both username and password.")
        return

    saved_username = new_username
    saved_password = new_password
    messagebox.showinfo("Success", "Credentials updated successfully!")

# Function to open the Message2U window
def open_message_2u():
    message_2u_window = tk.Toplevel(main_window)
    message_2u_window.title("Message2U")

    message_text = """
    Hello Professor! I hope this message finds you well. I appreciate you and all of the resources you have to offer throughout your course.
    Although I am only a guest student for Ivy Tech, I really enjoyed this course. It has made me very eager and excited for the programming 
    aspects of my Cybersecurity career and journey. I like that your final was not very specific and allowed for creativity. 
    I hope you have a great summer!
    """

    message_label = tk.Label(message_2u_window, text=message_text)
    message_label.pack(padx=20, pady=20)

# --- Main Code ---

# Create login window
login_window = tk.Tk()
login_window.title("Login")

# Image with alternate text (You should replace the image filenames here)
login_image_filename = "login_image.png"
login_image = tk.PhotoImage(file=login_image_filename)
login_label = tk.Label(login_window, image=login_image, text="Login Image")
login_label.pack(pady=10)

# Labels
label_username = tk.Label(login_window, text="Username:")
label_username.pack()
label_password = tk.Label(login_window, text="Password:")
label_password.pack()

# Entry fields for username and password
entry_username = tk.Entry(login_window)
entry_username.pack()
entry_password = tk.Entry(login_window, show="*")
entry_password.pack()

# Buttons with callbacks
login_button = tk.Button(login_window, text="Login", command=on_login)
login_button.pack(pady=10)
exit_button = tk.Button(login_window, text="Exit", command=on_exit)
exit_button.pack(pady=5)

# Hide the main window until the user logs in
main_window = tk.Toplevel(login_window)
main_window.title("Main Window")
main_window.withdraw()

# Image with alternate text (You should replace the image filenames here)
main_image_filename = "main_image.png"
main_image = tk.PhotoImage(file=main_image_filename)
main_label = tk.Label(main_window, image=main_image, text="Main Image")
main_label.pack(pady=10)

# Labels and placeholder text in the main window
label_info = tk.Label(main_window, text="Welcome to the Main Window")
label_info.pack()
label_placeholder = tk.Label(main_window, text="This is the main content of the application.")
label_placeholder.pack()

# Button to go back to the login window
back_button = tk.Button(main_window, text="Back to Login", command=on_back)
back_button.pack(pady=10)

# Entry fields to set new credentials in the main window
entry_new_username = tk.Entry(main_window)
entry_new_username.pack()
entry_new_password = tk.Entry(main_window, show="*")
entry_new_password.pack()
update_button = tk.Button(main_window, text="Set New Credentials", command=update_credentials)
update_button.pack(pady=10)

# Button to open Message2U window (Professor Only)
professor_only_label = tk.Label(main_window, text="Professor Only")
professor_only_label.pack(pady=10)
professor_entry = tk.Entry(main_window, show="*")
professor_entry.pack(pady=5)
professor_button = tk.Button(main_window, text="Open Message2U", command=lambda: open_message_2u() if professor_entry.get() == "SDevPro" else None)
professor_button.pack(pady=10)

# Set initial credentials (for demonstration purposes)
saved_username = "user123"
saved_password = "password"

# Run the application
login_window.mainloop()
